const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('deck', {
  pickFolder: () => ipcRenderer.invoke('pick-folder'),
  win: (cmd) => ipcRenderer.send('win', cmd)
});
