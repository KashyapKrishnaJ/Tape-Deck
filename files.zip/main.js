const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { pathToFileURL } = require('url');
const mm = require('music-metadata');
const EXT = /\.(mp3|m4a|flac|wav|ogg|aac|opus)$/i;
const covers = path.join(app.getPath('temp'), 'tape-deck-covers');

function walk(dir, out = [], depth = 0) {
  if (depth > 6) return out;
  let es; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of es) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out, depth + 1); else if (EXT.test(e.name)) out.push(p);
  }
  return out;
}

async function readTrack(p) {
  let c = {}, dur = 0, cover = null;
  try {
    const m = await mm.parseFile(p, { duration: true });
    c = m.common; dur = m.format.duration || 0;
    const pic = mm.selectCover(c.picture);
    if (pic) {
      const f = path.join(covers, crypto.createHash('md5').update(pic.data).digest('hex') + (pic.format.includes('png') ? '.png' : '.jpg'));
      if (!fs.existsSync(f)) fs.writeFileSync(f, pic.data);
      cover = pathToFileURL(f).href;
    }
  } catch {}
  return {
    url: pathToFileURL(p).href, title: c.title || path.basename(p, path.extname(p)),
    artist: c.artist || 'Unknown Artist', album: c.album || 'Unknown Album',
    year: c.year || '', no: (c.track && c.track.no) || 0, dur, cover
  };
}

ipcMain.handle('pick-folder', async () => {
  const r = await dialog.showOpenDialog({ properties: ['openDirectory'] });
  if (r.canceled) return null;
  fs.mkdirSync(covers, { recursive: true });
  const files = walk(r.filePaths[0]), out = []; let i = 0;
  await Promise.all(Array.from({ length: 8 }, async () => { while (i < files.length) out.push(await readTrack(files[i++])); }));
  return out.sort((a, b) => a.artist.localeCompare(b.artist) || a.album.localeCompare(b.album) || a.no - b.no);
});

ipcMain.on('win', (e, cmd) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (cmd === 'close') w.close(); else if (cmd === 'min') w.minimize();
});

app.whenReady().then(() => {
  const win = new BrowserWindow({
    width: 1040, height: 780, minWidth: 820, minHeight: 640, frame: false,
    backgroundColor: '#d5ccb4', title: 'Tape Deck',
    webPreferences: { preload: path.join(__dirname, 'preload.js') }
  });
  win.loadFile('index.html');
});
app.on('window-all-closed', () => app.quit());
